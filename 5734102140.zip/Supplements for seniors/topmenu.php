﻿<link rel="stylesheet" href="styles.css" type="text/css" />
<style type="text/css">
</style><div id="menucase">
  <div id="stylefour">
    <ul>
<!--      <li><a href="#" class="current">&nbsp;&nbsp;<img src="icon/17.gif" border="0">&nbsp;หน้าหลัก&nbsp;&nbsp;</a></li>
 -->      <li><a href="index.php">&nbsp;&nbsp;<img src="icon/17.gif" border="0">&nbsp;หน้าหลัก&nbsp;&nbsp;</a></li>
      <li><a href="?main=show_product">&nbsp;&nbsp;<img src="icon/clipboard_text.png" border="0" />&nbsp;สินค้าทั้งหมด&nbsp;&nbsp;</a></li>

           <li><a href="?main=show_product&sta=new">&nbsp;&nbsp;<img src="icon/vcard.png" border="0" />&nbsp;สินค้ามาใหม่&nbsp;&nbsp;</a></li>
	  <!--<li><a href="?main=show_promotion">&nbsp;&nbsp;<img src="icon/ipod_cast.png"  border="0"/>&nbsp;โปรโมชั่น&nbsp;&nbsp;</a></li> -->

      <li><a href="https://www.facebook.com/">&nbsp;&nbsp;<img src="icon/facebook.png" border="0">&nbsp;ติดต่อ&nbsp;&nbsp;</a></li>

    </ul>
  </div>
</div>
