﻿<?php if($_GET[upsta]){
Upsta($_GET[order_id],$_GET[upsta]);
}
?>

<?php
$nametb = "orders";
$namektb = "order_id";

?>
<?php
// ส่วนของการเพิ่ม ลบ แก้ไข ข้อมูล
if($_POST['ADD']){
//=================================UPLOAD==============================

//====================================================================
$q="INSERT INTO `$db`.`$nametb` (
`pro_id` ,
`group_id` ,
`pro_name` ,
`pro_pix` ,
`Detail` ,
`price_normal` ,
`price` 
)
VALUES (
NULL , '$_POST[group_id]', '$_POST[pro_name]  ', '$pro_pix', '$_POST[Detail]', '$_POST[price_normal] ', '$_POST[price]'
);
";
mysql_query($q);	
}
if($_GET['del']){
$q="DELETE FROM ".$nametb." WHERE "."$namektb"."="."'".$_GET['del']."' ";
mysql_query($q);
delcom();	
//exit;
}
if($_GET['up']){
	$q="SELECT * FROM ".$nametb." WHERE "."$namektb"."="."'".$_GET['up']."' ";
	$qr=mysql_query($q);	
	$rs=mysql_fetch_array($qr);
}
?>
<?php
if($_POST['UPDATE']){
$q="UPDATE `$db`.`$nametb` SET 
`group_id` = '$_POST[group_id]',
`pro_name` = '$_POST[pro_name]',
`Detail` = '$_POST[Detail]',
`price_normal` = '$_POST[price_normal]',
`price` = '$_POST[price]' ";
if(trim($_FILES["fileUpload"]["tmp_name"]) != ""){
$q.=", `pro_pix` = '$pro_pix'";
}
$q.=" WHERE `$nametb`.`$namektb` = $_POST[pro_id];";
echo $q;
mysql_query($q);
}
?><?php
$q="SELECT * FROM `$nametb`  ORDER BY `$nametb`.`$namektb` DESC  ";
$qr=mysql_query($q);
$total=mysql_num_rows($qr);
$e_page=20; // กำหนด จำนวนรายการที่แสดงในแต่ละหน้า   
if(!isset($_GET['s_page'])){   
	$_GET['s_page']=0;   
}else{   
	$chk_page=$_GET['s_page'];     
	$_GET['s_page']=$_GET['s_page']*$e_page;   
}   
$q.=" LIMIT ".$_GET['s_page'].",$e_page";
$qr=mysql_query($q);
if(mysql_num_rows($qr)>=1){   
	$plus_p=($chk_page*$e_page)+mysql_num_rows($qr);   
}else{   
	$plus_p=($chk_page*$e_page);       
}   
$total_p=ceil($total/$e_page);   
$before_p=($chk_page*$e_page)+1; 
?>
<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: x-small;
}
.style2 {font-weight: bold}
.style3 {font-weight: bold}
-->
</style>
<div id="stylized" class="myform">
  <h1>รายการสั่งซื้อ  </h1>
  <p>รายการสั่งซื้อสินค้า ทั้งหมด </p>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td><fieldset>
    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
      <tr>
        <td width="100" height="20" align="center" bgcolor="<?=$CH?>"><div align="left"><span class="style2">รหัสใบสั่งซื้อ</span></div></td>
        <td height="20" colspan="2" align="center" bgcolor="<?=$CH?>"><div align="left"><strong>วันที่สั่งซื้อ</strong></div>          
          <div align="left"></div></td>
        </tr>
      <?php
$i=1;
while($rs=mysql_fetch_array($qr)){
?>
      <?php 
$bg = ($bg=="$CLTB1")?"$CLTB2":"$CLTB1";
?>
      <tr bgcolor="<?php echo $bg?>" onmouseover="bgColor='<?=$CLOVER?>'" onmouseout="bgColor='<?=$bg?>'">
        <td height="20" align="left"><?=$rs[order_id]?></td>
        <td height="20" align="left"><fieldset>
            <?=con_to_textdate($rs[order_date])?> 
            <a href="slip_order.php?order_id=<?=$rs[order_id]?>" target="_blank">[<img src="icon/clipboard_text.png" width="16" height="16" border="0" />ดูรายการสั่งซื้อ]</a>
			<?php if($rs[status]!=N){?>
            <a href="slip_payment.php?order_id=<?=$rs[order_id]?>" target="_blank">[<img src="icon/zone_money.png" width="16" height="16" border="0" />ใบแจ้งชำระเงิน]            </a>
			
			<?php }?>
        </fieldset></td>
        <td width="16" align="left"><div align="center"><a href="?main=<?=$_GET[main]?>&del=<?=$rs[$namektb]?>" class="updateItem"><img src="icon/cross.gif" width="16" height="16" border="0" /></a></div></td>
      </tr>
      <?php $i++; } ?>
    </table>
    </fieldset> </td>
  </tr>
</table>
<?php if($total>0){ ?>
<div class="browse_page">
  <div align="center">
    <?php   
 // เรียกใช้งานฟังก์ชั่น สำหรับแสดงการแบ่งหน้า   
  page_navigator($before_p,$plus_p,$total,$total_p,$chk_page);     
  ?>
    <br />
    ทั้งหมด  <?php echo $total ; ?>รายการ
    
  </div>
</div>
<div align="center">
  <?php } ?>
</div>
</div>
