<?php
// ส่วนของการเพิ่ม ลบ แก้ไข ข้อมูล
if($_POST['ADD']){
//=================================UPLOAD==============================

	if(trim($_FILES["fileUpload"]["tmp_name"]) != "")
	{
		$images = $_FILES["fileUpload"]["tmp_name"];
		$todayrename = date("YmdHis");
		$new_images = "Thumbnails_".$_FILES["fileUpload"]["name"];
		move_uploaded_file($_FILES["fileUpload"]["tmp_name"],"Timageproduct/"."$todayrename".$_FILES["fileUpload"]["name"]);
		$pro_pix = $todayrename.$_FILES["fileUpload"]["name"];
		/*
		$width=100; //*** Fix Width & Heigh (Autu caculate) 
		$size=GetimageSize($images);
		$height=round($width*$size[1]/$size[0]);
		$images_orig = ImageCreateFromJPEG($images);
		$photoX = ImagesX($images_orig);
		$photoY = ImagesY($images_orig);
		$images_fin = ImageCreateTrueColor($width, $height);
		ImageCopyResampled($images_fin, $images_orig, 0, 0, 0, 0, $width+1, $height+1, $photoX, $photoY);
		ImageJPEG($images_fin,"Timageproduct/".$new_images);
		ImageDestroy($images_orig);
		ImageDestroy($images_fin);
		*/
	}
		
//====================================================================
$q="INSERT INTO `$db`.`product` (
`pro_id` ,
`group_id` ,
`pro_name` ,
`pro_pix` ,
`Detail` ,
`price_normal` ,
`price` 
)
VALUES (
NULL , '$_POST[group_id]', '$_POST[pro_name]  ', '$pro_pix', '$_POST[Detail]', '$_POST[price_normal] ', '$_POST[price]'
);
";
mysql_query($q);	
}
if($_GET['method']=="delete"){
	$q="DELETE FROM tbl_member WHERE member_id='".$_POST['id']."' ";
	mysql_query($q);	
	exit;
}
if($_GET['method']=="getupdate"){
	$q="SELECT * FROM tbl_member WHERE member_id='".$_POST['id']."' ";
	$qr=mysql_query($q);	
	$rs=mysql_fetch_array($qr);
	exit;
}
?>
<?php
$q="SELECT * FROM `product` WHERE `status` = 'Y' ";
if($_GET[group_id]){
$q.=" AND `group_id` = $_GET[group_id]  ";
}
$q.=" ORDER BY `product`.`pro_id` DESC   ";
$qr=mysql_query($q);
$total=mysql_num_rows($qr);
if($_GET[group_id]){//ถ้าแบ่งกลุ่ม
$e_page=100; // กำหนด จำนวนรายการที่แสดงในแต่ละหน้า   
}else{
$e_page=5; // กำหนด จำนวนรายการที่แสดงในแต่ละหน้า   
}
if(!isset($_GET['s_page'])){   
	$_GET['s_page']=0;   
}else{   
	$chk_page=$_GET['s_page'];     
	$_GET['s_page']=$_GET['s_page']*$e_page;   
}   
 $q.=" LIMIT ".$_GET['s_page'].",$e_page";
$qr=mysql_query($q);
if(mysql_num_rows($qr)>=1){   
	$plus_p=($chk_page*$e_page)+mysql_num_rows($qr);   
}else{   
	$plus_p=($chk_page*$e_page);       
}   
$total_p=ceil($total/$e_page);   
$before_p=($chk_page*$e_page)+1;  
?>

<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: x-small;
}
.style2 {font-weight: bold}
.style7 {color: #666666; font-weight: bold; }
-->
</style>
<h2 align="right"><font color="#B3100B"><?php if($_GET[sta]=='new'){?>
  สินค้ามาใหม่<img src="icon/menu.png" width="48" height="48" />
<?php }else if($_GET[group_id]){?><?php 	$q3="SELECT * FROM `group` WHERE `group_id` =$_GET[group_id]";
		$qr3=mysql_query($q3);
		$rs3=mysql_fetch_array($qr3);
		echo $rs3[group_name]; 
?>
<img src="icon/icon-48-module.png" width="48" height="48" />
<?php }else{?>
สินค้าทั้งหมด<img src="images/ecom_icon.jpg" width="48" />
<?php }?></font></h2>
<h2 align="center">
</h2>
<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
	<?php if($_GET[sta]=='new'){}else{?>
	<div align="right">
      <?php   
 // เรียกใช้งานฟังก์ชั่น สำหรับแสดงการแบ่งหน้า   
  page_navigator($before_p,$plus_p,$total,$total_p,$chk_page);     
  ?>
      <br />
      พบสินค้า <?php echo $total ; ?> รายการ    </div>
	  <?php }?>
	  
    </td>
  </tr>
</table>
<br />
<table width="90%" border="0" align="center" cellpadding="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td><fieldset>
    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
      <?php
$i=1;
while($rs=mysql_fetch_array($qr)){
?>
      <?php 
?>
      <tr >
        <td width="142" height="20" align="left">&nbsp;
          <fieldset>
          <div align="center"><a href="?main=product_de&amp;id=<?=$rs['pro_id']?>">
            
  <img src="Timageproduct/<?php if($rs['pro_pix']){ echo $rs['pro_pix'];}else{echo "nopix.gif";}?>" width="140" border="0" /><br /> 
            </a>เพิ่มเติม          </div>
        </fieldset></td>
        <td width="849" height="20" align="left"><font color="#F88D3B"><span class="style2">
          <?=$rs['pro_name']?>
        </span></font>
          <fieldset><legend>รายละเอียด</legend>
          <p>
            <?=$rs['Title']?>
          </p>
        </fieldset></td>
        <td width="157" height="20" align="left">    
            <p><a href="#<?=$rs['member_id']?>" class="updateItem"></a></p>
            <form action="?main=cart" method="post" onsubmit="return checkform(this,<? echo $unit; ?>);">
              <input type="hidden" name="product_id" value="<?echo $rs[pro_id]; ?>" />
              <input name="price" type="hidden" value="<? echo $rs[price]; ?>" />
              <table border="0" cellpadding="5" cellspacing="0" style="border-collapse: collapse; border: 1px dashed #800000" bordercolor="#CCCCCC" width="90%" >
                <tr>
                  <td style="border: 1px dashed #800000"><div align="center">
                    <table width="90%" border="0" cellspacing="3" cellpadding="0">
                      <tr>
                        <td><span class="style7">ราคาปกติ</span></td>
                        <td><div align="right"><span class="style7">
                          <?=number_format($rs['price_normal'])?>
                        </span></div></td>
                        <td><span class="style7">บาท</span></td>
                      </tr>
                      <tr>
                        <td><strong>พิเศษ</strong></td>
                        <td><div align="right"><strong>
                          <?=number_format($rs['price'])?>
                        </strong></div></td>
                        <td><strong>บาท</strong></td>
                      </tr>
                    </table>
                  </div></td>
                </tr>
                <tr>
                  <td width="100%" style="border: 1px dashed #800000"><?php if($_SESSION[STA]=="MEMBER"){?>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td>จำนวน
                    :&nbsp;</td>
                        <td><input name="qty" type="text" value="1" size="2" /></td>
                      </tr>
                    </table>
                    <br />
                    &nbsp;
                    <center>
                    <INPUT TYPE="image" SRC="icon/addcart.gif"  BORDER="0" ALT="Submit Form">
  <?php }?>
                  </center></td>
                </tr>
              </table>
          </form>            </td>
        </tr>
      <tr >
        <td height="20" colspan="3" align="left"><hr color="#0099CC" /></td>
        </tr>
      <?php $i++; } ?>
    </table>
    </fieldset>
     </td>
  </tr>
</table>
<?php if($total>0){ ?>
<div class="browse_page">

<?php if($_GET[sta]){}else{?>
  <div align="center">
    <?php   
 // เรียกใช้งานฟังก์ชั่น สำหรับแสดงการแบ่งหน้า   
  page_navigator($before_p,$plus_p,$total,$total_p,$chk_page);     
  ?>
    <br />
    พบสินค้า
    <?php echo $total ; ?> รายการ
    
  </div>
  <?php }?>
  
  
</div>
<div align="center">
  <?php } ?>
</div>
