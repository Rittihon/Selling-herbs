-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2017 at 03:41 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomjaroenjit`
--

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `group_id` int(11) NOT NULL COMMENT 'รหัสกลุ่ม',
  `group_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อกลุ่ม'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`group_id`, `group_name`) VALUES
(1, 'บำรุงร่างกายโดยรวม ช/ญ'),
(2, 'บำรุงสายตา'),
(3, 'บำรุงสมอง/ความจำ'),
(4, 'บำรุงกระดูกให้แข็งแรง'),
(5, 'ซ่อมแซมส่วนที่สึกหรอ'),
(7, 'บำรุงผิวพรรณให้อ่อนวัย');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `identily` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `tel` text COLLATE utf8_unicode_ci NOT NULL,
  `Status` enum('MEMBER','ADMIN') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`username`, `password`, `name`, `address`, `email`, `identily`, `tel`, `Status`) VALUES
('ritti', 'Dook4996316', 'นายฤทธิพล  กัญญาเขียว', '41/4 ต. อ. จ. 41060', 'Dluk616@gmail.com', '0828159147', '0933333333', 'ADMIN'),
('tomtam ', '5734102140', 'ประยุทธ์', '123/8 ต.หนองกอมเกาะ อ.เมืองหนองคาย จ.หนองคาย 43000 ', 'niwat@gmail.com', '1234567891234', '095555555', 'MEMBER');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `orderdetails_id` int(11) NOT NULL COMMENT 'รหัสรายละเอียดการสั่งซื้อ',
  `order_id` varchar(12) COLLATE utf8_unicode_ci NOT NULL COMMENT 'รหัสใบสั่งซื้อ',
  `pro_id` int(11) NOT NULL COMMENT 'รหัสสินค้า',
  `qty` int(11) NOT NULL COMMENT 'จำนวน',
  `price` int(11) NOT NULL COMMENT 'ราคา'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` varchar(12) COLLATE utf8_unicode_ci NOT NULL COMMENT 'เลขที่ใบสั่งซื้อ',
  `username` varchar(300) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อผู้สั่ง',
  `order_date` date NOT NULL COMMENT 'วันที่สั่ง',
  `order_time` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'เวลาที่สั่ง',
  `status` enum('N','R','Y') COLLATE utf8_unicode_ci NOT NULL COMMENT 'สถานะ'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pro_id` int(11) NOT NULL COMMENT 'รหัสสินค้า',
  `group_id` int(11) NOT NULL COMMENT 'รหัสกลุ่ม',
  `pro_name` varchar(300) COLLATE utf8_unicode_ci NOT NULL COMMENT 'ชื่อรูป',
  `pro_pix` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'รูปภาพ',
  `Title` text COLLATE utf8_unicode_ci NOT NULL,
  `Detail` text COLLATE utf8_unicode_ci NOT NULL COMMENT 'รายละเอียดสินค้า',
  `price_normal` double NOT NULL COMMENT 'ราคาปกติ',
  `price` double NOT NULL COMMENT 'ราคาขาย',
  `status` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pro_id`, `group_id`, `pro_name`, `pro_pix`, `Title`, `Detail`, `price_normal`, `price`, `status`) VALUES
(30, 1, 'ซูปรา วิต-เอ็ม  ', '20170514135347a1.jpg', 'ผลิตภัณฑ์เสริมอาหาร วิตามินและเกลือแร่รวม ผสมไลโคปีน ชนิดเม็ด ตรากิฟฟารีน', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 เม็ด : ไดแคลเซียมฟอสเฟต ไดไฮเดรต  625 มก,ผงวิตามินและเกลือแร่รวม  250 มก,ไลโคปีน 10%  30 มก.\r\nวิธีรับประทาน : วันละ 1 เม็ด  พร้อมอาหาร\r\nคำเตือน : อ่านคำเตือนในฉลากก่อนบริโภค ไม่มีผลในการป้องกันหรือรักษาโรค\r\nขนาด 60 เม็ด                ', 500, 200, 'Y'),
(31, 1, 'ซูปรา วิต-ดับเบิ้ลยู  ', '20170514135632a2.jpg', 'ผลิตภัณฑ์เสริมอาหาร วิตามินและเกลือแร่รวม ผสมจมูกถั่วเหลือง ชนิดเม็ด ตรากิฟฟารีน', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 เม็ด :\r\nไดแคลเซียมฟอสเฟต ไดไฮเดรต  625 มก,ผงวิตามินและเกลือแร่รวม  250 มก,จมูกถัวเหลือง  100 มก.\r\nวิธีรับประทาน :  วันละ 1 เม็ด  พร้อมอาหาร\r\nคำเตือน : อ่านคำเตือนในฉลากก่อนบริโภค ไม่มีผลในการป้องกันหรือรักษาโรค\r\nขนาด 60 เม็ด                 ', 400, 100, 'Y'),
(36, 1, 'ผกดิ  ', '20170514140901บำรุงกระดูก.jpg', 'ฺฆโฺ', '                  ำก้ืิหด', 0, 0, 'N'),
(37, 3, 'ดเ้้เห  ', '20170514140953a1.jpg', 'กเเกเก', '                  กเ่ก้', 0, 0, 'N'),
(38, 3, 'โคลีน บี  ', '20170514141344b5.jpg', 'ผลิตภัณฑ์เสริมอาหาร โคลีน ไบทาร์เทรต ผสมวิตามินบีคอมเพล็กซ์ ชนิดแคปซูล  ตรากิฟฟารีน', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 แคปซูล :\r\nโคลีน ไบทาร์เทรต 445.75 มก. (ให้โคลีน 183.34 มก.)     \r\nวิตามินบี1, วิตามินบี2 และวิตามินพรีมิกซ์รวม 19.6 มก. \r\n(ให้วิตามินบี1  0.30มก., วิตามินบี5  0.34มก., วิตามินบี3  3.71มก., วิตามินบี5  1.22มก., วิตามินบี6  0.46มก. และวิตามินบี12  0.55 มคก.)\r\nวิธีรับประทาน : รับประทานวันละ 1-3 แคปซูล พร้อมอาหาร\r\nคำเตือน : อ่านคำเตือนในฉลากก่อนบริโภค ไม่มีผลในการป้องกันหรือรักษาโรค\r\nขนาด 30 แคปซูล                  ', 500, 200, 'Y'),
(39, 4, 'แคล-ดี-แมก   ', '20170514141523b3.jpg', 'ผลิตภัณฑ์เสริมอาหาร แคลเซียม ผสมวิตามินดี3,ซี,อี,แมกนีเซียม,สังกะสีและทองแดง ชนิดเม็ ตรา กิฟฟารีน', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 เม็ด :\r\nแคลเซียม  400 มก.    แมกนีเซียม  54 มก. วิตามินดี3  90 หน่วยสากล     วิตามินซี  32 มก.\r\nสังกะสี  4.2 มก. วิตามินอี  3 หน่วยสากล    ทองแดง  0.45 มก\r\nวิธีรับประทาน : รับประทานครั้งละ 1 เม็ด พร้อมอาหารเช้า-เย็น\r\nคำเตือน : อ่านคำเตือนในฉลากก่อนบริโภค ไม่มีผลในการป้องกันหรือรักษาโรค\r\nขนาด 60 เม็ด                  ', 500, 100, 'Y'),
(40, 4, 'แคล-ดี-แมก 600   ', '20170514141710b4.jpg', 'ผลิตภัณฑ์เสริมอาหารแคลเซียม ผสมแมกนีเซียม,วิตามินซี,สังกะสี,แมงกานีส,ทองแดง,วิตามินอี และวิตามินดี3 ชนิดเม็ด ตรากิฟฟารีน', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 เม็ด :\r\nแคลเซียม  600 มก.    แมกนีเซียม  53 มก    วิตามินดี3  200 หน่วยสากล    วิตามินซี  30 มก.\r\nวิตามินอี  3 หน่วยสากล    สังกะสี  7.5 มก.    ทองแดง  1 มก.    แมงกานีส  2 มก.\r\nวิธีรับประทาน : ครั้งละ 1 เม็ด วันละ 1 ครั้ง พร้อมอาหาร\r\nคำเตือน : อ่านคำเตือนในฉลากก่อนบริโภค ไม่มีผลในการป้องกันหรือรักษาโรค\r\nขนาด 30 แคปซูล                  ', 450, 200, 'Y'),
(41, 2, 'แอล ซี วิต พลัส เอ  ', '20170514141905b6.png', 'ผลิตภัณฑ์เสริมอาหาร ลูทีน และซีแซนทีน ผสมวิตามินเอ ชนิดแคปซูล ตรากิฟฟารีน ', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 แคปซูล :\r\nลูทีน 20% 15.75 มก.(ให้ลูทีน 3.15 มก.)\r\nซีแซนทีน 20% 15.75 มก.(ให้ซีแซนทีน 3.15 มก.)\r\nวิตามินเอ แพลทิเมต 1332 มก.(ให้วิตามินเอ 1332 มก.หน่วยสากล)\r\nวิธีรับประทาน : รับประทานวันละ 1-2 แคปซูล พร้อมอาหาร\r\nคำเตือน : อ่านคำเตือนในฉลากก่อนบริโภค ไม่มีผลในการป้องกันหรือรักษาโรค\r\nขนาด 30 แคปซูล                  ', 600, 200, 'Y'),
(42, 5, 'โซย่า-เวย์ โปรตีน  ', '20170514142041b2.jpg', 'ผลิตภัณฑ์เสริมอาหาร โปรตีนสกัดเข้มข้นจากถั่วเหลืองและนม ชนิดผง ตรากิฟฟารีน', 'ส่วนประกอบที่สำคัญโดยประมาณใน 1 ซอง :\r\nโปรตีนสกัดจากถั่วเหลือง  72.91%(7.47ก.)    โปรตีนสกัดเข้มข้นจากนม  23.64%(2.42ก.)  \r\n แคลเซียมคาร์บอเนต  1.97%(0.20ก.)    แอล-เมไธโอนีน  0.59%(60.6มก.)\r\nวิธีรับประทาน : รับประทานวันละ 1 ซอง พร้อมมื้ออาหาร โดยผสมผลิตภัณฑ์ 1 ซอง ในอาหารหรือเครื่องดื่มต่างๆ เช่น ข้าวสวย ผัดผักต่างๆ นม น้ำผลไม้ ชา กาแฟ                  ', 700, 300, 'Y'),
(43, 7, 'Coenzyme Q10  ', '20170514144728kp.jpg', 'ผลิตภัณฑ์เสริมอาหาร  ช่วยชะลอความชรา', '1.) ช่วยในการบำรุงผิวพรรณ\r\n2.) ช่วยเพิ่มประสิทธิการทำงานของกล้ามเนื้อหัวใจ\r\n3.) ช่วยยับยั้งการจับตัวเป็นก้อนแข็งของเลือด\r\n4.) ช่วยป้องกันโรคอัลไซเมอร์\r\n5.) มีคุณสมบัติต้านอนุมูลอิสระ\r\n6.) ช่วยชะลอการเสื่อมของเซลล์\r\n7.) ช่วยลดเลือนริ้วรอย\r\n8.) ช่วยลดผลข้างเคียงของการใช้ยาลดไขมัน\r\n9.) ช่วยลดคอเรสเตอรอลในหลอดเลือด\r\n10.) ช่วยลดความเสี่ยงของการเกิดโรคความดันโลหิตสูง                                                      ', 500, 100, 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`orderdetails_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pro_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสกลุ่ม', AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `orderdetails_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสรายละเอียดการสั่งซื้อ', AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pro_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'รหัสสินค้า', AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
