<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#111111" id="AutoNumber1" style="border-collapse: collapse; border: 1px dashed #800000">
  <tr>
    <td colspan="3" valign="top" ><div align="center"><b>โปรดโอนเงินเข้าบัญชีต่อไปนี้</b></div></td>
  </tr>
  <tr>
    <td valign="top" ><div align="center"><img src="icon/ks.jpg" width="170" height="43"></div></td>
    <td valign="top" ><div align="center"><img src="icon/bk.jpg" width="108" height="48"></div></td>
    <td valign="top" ><div align="center"><img src="icon/scb.jpg" width="80" height="53"></div></td>
  </tr>
  <tr>
    <td width="33%" valign="top" ><p align="center">&nbsp;<br>
      ธนาคาร :
      กรุงศรีอยุธยา<br>
      &nbsp;สาขา : หนองคาย <br>
      &nbsp;เลขที่บัญชี : 123456789 <br>
      &nbsp;ชื่อบัญชี : ฤทธิพล  กัญญเขียว</p></td>
    <td width="32%" valign="top" ><div align="center"><br>
      ธนาคาร :
      กรุงเทพ<br>
      &nbsp;สาขา : หนองคาย <br>
      &nbsp;เลขที่บัญชี : 1234567890 <br>
      &nbsp;ชื่อบัญชี : ชื่อบัญชี : ฤทธิพล  กัญญเขียว</div></td>
    <td width="35%" valign="top" ><div align="center"><br>
      ธนาคาร :
      ไทยพาณิชย์<br>
      &nbsp;สาขา : หนองคาย <br>
      &nbsp;เลขที่บัญชี : 1234567890 <br>
      &nbsp;ชื่อบัญชี : ชื่อบัญชี : ฤทธิพล  กัญญเขียว</div></td>
  </tr>
</table>
