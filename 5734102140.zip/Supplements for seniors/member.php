﻿<?php
$nametb = "member";
$namektb = "username";
?>
<?php
// ส่วนของการเพิ่ม ลบ แก้ไข ข้อมูล
if($_POST['ADD']){
	$q="INSERT INTO `$db`.`member` (
`username` ,
`password` ,
`name` ,
`address` ,
`email` ,
`identily` ,
`tel` 
)
VALUES (
'$_POST[username] ', '$_POST[password]', '$_POST[name]', '$_POST[address]', '$_POST[email]', '$_POST[identily]  ', '$_POST[tel]'
);
";
mysql_query($q);	
}
if($_GET['del']){
$q="DELETE FROM `$db`.`$nametb` WHERE `$nametb`.`$namektb` = '$_GET[del]';
";
mysql_query($q);
delcom();	
//exit;
}
if($_GET['up']){
	$up = $_GET['up'];
	$q="SELECT * FROM `member` WHERE `username` = '$up'";
	$qr=mysql_query($q);	
	$rs=mysql_fetch_array($qr);
}
?>
<?php
if($_POST['UPDATE']){
 $q="UPDATE `$db`.`$nametb` 
SET `password` = '$_POST[password]', 
`name` = '$_POST[name]',
`address` = '$_POST[address]',
`email` = '$_POST[email]',
`identily` = '$_POST[identily]',
`tel` = '$_POST[tel]' 
WHERE `member`.`username` = '$_POST[username]'
";
//echo $q;
mysql_query($q);
}
?><div id="stylized" class="myform">

<form action="" method="post" enctype="multipart/form-data" name="frmMain">  <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td>        <legend></legend>        
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="2">
          <tr>
            <td colspan="2" align="right"><div align="left">
              <h1><img src="icon/cart.gif" width="16" height="17" />ข้อมูลสมาชิก</h1>
              <br />
             <p> เพิ่มและแก้ใขข้อมูลสมาชิก</p>
            </div></td>
            </tr>
          <tr>
            <td width="158" align="right" valign="top">&nbsp;</td>
              <td width="762" align="left" valign="top">&nbsp;</td>
            </tr>
          <tr>
            <td valign="top"><div align="right"><strong>ชื่อผู้ใช้</strong></div>
                <div align="right"><span class="small">Username</span> </div></td>
            <td valign="top"><em>
              <input name="username"  type="text" id="username" value="<?=$rs[$namektb]?>" />
            </em></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>รหัสผ่าน<br />
                      <span class="small">Password</span></strong></div></td>
            <td valign="top"><input name="password" type="password" id="password" value="<?=$rs[password]?>" /></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>ชื่อ-สกุล<br />
                      <span class="small">Name-Lastname</span></strong></div></td>
            <td valign="top"><input name="name" type="text" id="name" value="<?=$rs[name]?>" /></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>รหัสบัตรประชาชน<br />
                      <span class="small">identily</span></strong></div></td>
            <td valign="top"><input name="identily" type="text" id="identily"  value="<?=$rs[identily]?>"/></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>ที่อยู่</strong></div>
                <div align="right"><strong><span class="small">ที่อยู่ในการจัดส่งสินค้า</span><br />
              </strong></div></td>
            <td valign="top">&nbsp;&nbsp;
              <textarea name="address" cols="60" rows="5" id="address" ><?=$rs[address]?></textarea></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>เบอร์โทร<br />
                      <span class="small">ที่สามารถติดต่อได้</span></strong></div></td>
            <td valign="top"><input name="tel" type="text" id="tel" value="<?=$rs[tel]?>" /></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>Email<br />
                      <span class="small">จดหมายอิเล็กทรอนิกส์</span></strong></div></td>
            <td valign="top"><input name="email" type="text" id="email" value="<?=$rs[email]?>" /></td>
          </tr>
          
          <tr>
            <td align="right">&nbsp;</td>
              <td align="left"><em>
                <?php if($_GET['up']){?>
                <input type="submit" name="UPDATE" id="UPDATE" value="UPDATE" />
                <?php }else{?>
                <input type="submit" name="ADD" id="ADD" value="ADD" />
                <?php }?>
                <input type="button" name="cancel" id="cancel" value="Cancel" />
              </em></td>
            </tr>
        </table></td></tr>
  </table>
</form>

<?php
 $q="SELECT * 
FROM `$nametb` 
ORDER BY `$nametb`.`$namektb` ASC  ";
$qr=mysql_query($q);
$total=mysql_num_rows($qr);
$e_page=20; // กำหนด จำนวนรายการที่แสดงในแต่ละหน้า   
if(!isset($_GET['s_page'])){   
	$_GET['s_page']=0;   
}else{   
	$chk_page=$_GET['s_page'];     
	$_GET['s_page']=$_GET['s_page']*$e_page;   
}   
$q.=" LIMIT ".$_GET['s_page'].",$e_page";
$qr=mysql_query($q);
if(mysql_num_rows($qr)>=1){   
	$plus_p=($chk_page*$e_page)+mysql_num_rows($qr);   
}else{   
	$plus_p=($chk_page*$e_page);       
}   
$total_p=ceil($total/$e_page);   
$before_p=($chk_page*$e_page)+1; 
?>
<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: x-small;
}
-->
</style>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td>      <table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
        <tr>
          <td height="20" align="center" bgcolor="<?=$CH?>"><div align="left"><strong>USERNAME</strong></div>
            <div align="left"></div>            <div align="left"></div></td>
          <td height="20" align="center" bgcolor="<?=$CH?>"><div align="left"><strong>ชื่อ-สกุล</strong></div></td>
          <td height="20" align="center" bgcolor="<?=$CH?>">&nbsp;</td>
          <td height="20" colspan="2" align="center" bgcolor="<?=$CH?>"><a href="?main=<?=$_GET[main]?>"><strong><img src="icon/add.png" alt="เพิ่ม" width="16" height="16" border="0" /></strong></a></td>
          </tr>
        <?php
$i=1;
while($rs=mysql_fetch_array($qr)){
?>
        <?php 
$bg = ($bg=="$CLTB1")?"$CLTB2":"$CLTB1";
?>
        <tr bgcolor="<?php echo $bg?>" onmouseover="bgColor='<?=$CLOVER?>'" onmouseout="bgColor='<?=$bg?>'">
          <td width="39" height="20" align="left"><?=$rs['username']?></td>
            <td width="776" height="20" align="left"><?=$rs['name']?></td>
            <td width="144" height="20" align="left">&nbsp;</td>
            <td width="19" height="20" align="center"><a href="?main=<?=$_GET[main]?>&up=<?=$rs[$namektb]?>" class="updateItem"><img src="icon/edit.png" alt="แก้ไข" width="16" height="16" border="0" /></a></td>
            <td width="21" align="center"><a href="?main=<?=$_GET[main]?>&del=<?=$rs[$namektb]?>" class="updateItem"><img src="icon/cross.gif" alt="ลบ" width="16" height="16" border="0" onClick='return Conf(this)' /></a></td>
          </tr>
        <?php $i++; } ?>
      </table>
   </td></tr>
</table>
<?php if($total>0){ ?>
<div class="browse_page">
  <div align="center">
    <?php   
 // เรียกใช้งานฟังก์ชั่น สำหรับแสดงการแบ่งหน้า   
  page_navigator($before_p,$plus_p,$total,$total_p,$chk_page);     
  ?>
    <br />
    ทั้งหมด  <?php echo $total ; ?>รายการ
    
  </div>
</div>
<div align="center">
  <?php } ?>
</div>
</div>
