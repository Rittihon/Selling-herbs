<?php
$server='localhost';
$user='root';
$password='';
$database='ecomjaroenjit';
?>
