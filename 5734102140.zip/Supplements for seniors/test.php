<html>
<head>
<title>Jaroenjit PHP Upload</title>
</head>
<body>
<form action="" method="post" enctype="multipart/form-data" name="frmMain">
<table width="343" border="1">
<tr>
<td>Upload</td>
<td><input name="fileUpload" type="file"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Submit"></td>
</tr>
</table>
</form>
<?
	if(trim($_FILES["fileUpload"]["tmp_name"]) != "")
	{
		$images = $_FILES["fileUpload"]["tmp_name"];
		$new_images = "Thumbnails_".$_FILES["fileUpload"]["name"];
		move_uploaded_file($_FILES["fileUpload"]["tmp_name"],"Timageproduct/".$_FILES["fileUpload"]["name"]);
		$width=100; //*** Fix Width & Heigh (Autu caculate) ***//
		$size=GetimageSize($images);
		$height=round($width*$size[1]/$size[0]);
		$images_orig = ImageCreateFromJPEG($images);
		$photoX = ImagesX($images_orig);
		$photoY = ImagesY($images_orig);
		$images_fin = ImageCreateTrueColor($width, $height);
		ImageCopyResampled($images_fin, $images_orig, 0, 0, 0, 0, $width+1, $height+1, $photoX, $photoY);
		ImageJPEG($images_fin,"Timageproduct/".$new_images);
		ImageDestroy($images_orig);
		ImageDestroy($images_fin);
	}
?>
<b>Original Size</b><br>
<img src="<?="Timageproduct/".$_FILES["fileUpload"]["name"];?>">
<hr>
<b>New Resize</b><br>
<img src="<?="Timageproduct/".$new_images;?>">
</body>
</html>
