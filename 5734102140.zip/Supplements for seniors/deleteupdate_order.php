<?
include "dbconfig.php";
conndb();

$order_id = $_GET['order_id']; //-------------------------------

?>

<!-- ยังมีข้อผิดพลาดบางส่วนครับ -->
<script>
     alert("");
</script>


<?
// ลบบรรทัด order ออก
$sql = "delete from orders where order_id=$order_id";
$result = mysql_query($sql);

// ลบบรรทัด order ออก
$sql2 = "delete from orderdetails where order_id=$order_id";
$result2 = mysql_query($sql2);

CloseDB();
echo "<meta http-equiv='refresh' content='0;url=manageorder.php'>" ;
?>
