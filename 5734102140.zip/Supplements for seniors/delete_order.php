<?
include "dbconfig.php";
conndb();

$order_id = $_GET['order_id']; //-------------------- 

//---------------------------------------------------
$sql = "delete from orders where order_id=$order_id";
$result = mysql_query($sql);

//---------------------------------------------------------
$sql2 = "delete from orderdetails where order_id=$order_id";
$result2 = mysql_query($sql2);

CloseDB();
echo "<meta http-equiv='refresh' content='0;url=manageorder.php'>" ;
?>
