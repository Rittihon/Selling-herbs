﻿<table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
	<?php if($_SESSION[STA]=="" && $_GET[main]!="frm_reg"){?>	
	<p align="center">
	<?php 
	$login = "login.php";
	include("$login");?><br />
	<?php }?>
	  <?php if($_SESSION[STA]=="MEMBER"){?>	  
      </p>
	  <fieldset>
      <legend><strong><img src="icon/icon-48-user.png" width="48" height="48" border="0" />เมนูสมาชิก</strong></legend>
      <p><img src="icon/bottom-empty.gif" width="19" height="16" /><a href="?main=profile"><img src="icon/user_thief_baldie.png" width="16" height="16" border="0" />ข้อมูลส่วนตัว</a><br />
        <a href="?main=cart"><img src="icon/bottom-empty.gif" width="19" height="16" border="0" /><img src="icon/cart.png" width="16" height="16" border="0" />&nbsp;ตะกร้าสินค้า</a><br />
        <a href="?main=order_list"><img src="icon/bottom-empty.gif" width="19" height="16" border="0" /><img src="icon/icon-16-article.png" width="16" height="16" border="0" />&nbsp;รายการสั่งซื้อ</a><br />
       <!-- <img src="icon/bottom-empty.gif" width="19" height="16" /><a href="?main=show_promotion"><img src="icon/icon-16-default.png" width="16" height="16" border="0" />&nbsp;โปรโมชั่น</a><br /> -->
          <a href="?main=logout"><img src="icon/bottom-empty.gif" width="19" height="16" border="0" /><img src="icon/remove.png" width="16" height="16" border="0" />&nbsp;ออกจากระบบ</a><br />
      </p>
      </fieldset>
	  <?php }?>
	  <fieldset><legend><strong><img src="icon/shopping_cart.png" width="48" height="48" />สินค้า</strong></legend>
      <p><a href="?main=show_product&amp;group_id=<?=$rs['group_id']?>"><img src="icon/5_121.gif" width="7" height="9" border="0" /></a>&nbsp;<a href="?main=show_product">สินค้าทั้งหมด</a><br />
        <?php
	$q="SELECT * FROM `group`";
	$qr=mysql_query($q);	
	while($rs=mysql_fetch_array($qr)){
	?>
        <a href="?main=show_product&group_id=<?=$rs['group_id']?>"><img src="icon/application_go.png" width="16" height="16" border="0" />
        <?=$rs['group_name']?></a>
	<br />
	<?php }?>
      </p>
      </fieldset>
      </p>
      <div align="center">
        <?php if($_SESSION[STA]=="ADMIN"){?>
</div>
      <fieldset><legend><strong><img src="icon/menu.png" width="48" height="48" />เมนูผู้ดูแลระบบ</strong></legend>
      <br />
      <img src="icon/bottom-empty.gif" width="19" height="16" /><img src="icon/user_thief_baldie.png" width="16" height="16" /><a href="?main=profile">&nbsp;ข้อมูลส่วนตัว</a><br />
      <img src="icon/bottom-empty.gif" width="19" height="16" /><a href="?main=member"><img src="icon/icon-16-user.png" width="16" height="16" border="0" />&nbsp;ข้อมูลสมาชิก</a><br />
      <a href="?main=product"><img src="icon/bottom-empty.gif" width="19" height="16" border="0" /><img src="icon/tar.png" width="16" height="16" border="0" />&nbsp;ข้อมูลสินค้า</a><br />
      <a href="?main=group"><img src="icon/bottom-empty.gif" width="19" height="16" border="0" /><img src="icon/wmv.png" width="16" height="16" border="0" />&nbsp;ข้อมูลกลุ่มสินค้า</a><br />
      <img src="icon/bottom-empty.gif" width="19" height="16" /><a href="?main=order"><img src="icon/rtf.png" width="16" height="16" border="0" />&nbsp;ข้อมูลการสั่งซื้อ</a>      <br />
      <!--<img src="icon/bottom-empty.gif" width="19" height="16" /><a href="?main=promotion"><img src="icon/content.png" width="16" height="16" border="0" />&nbsp;โปรโมชั่น</a><br /> --><a href="?main=logout"><img src="icon/bottom-empty.gif" width="19" height="16" border="0" /><img src="icon/remove.png" width="16" height="16" border="0" />&nbsp;ออกจากระบบ</a>
      </fieldset>
	  <?php }?>	  </td>
  </tr>
  
  <tr>
    <td><p>
      </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
<tr>
  <td>&nbsp;</td>
</tr>
</table>
