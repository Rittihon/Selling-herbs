﻿<?php  ob_start(); ?>
<?php @session_start();?>
<?php include("connect/inc.php");?>
<?php include("function.php"); ?>
<?php //require_once("ValidateForm.cls.php"); ?>
<font color="#FFFFFF">
<?php //echo $_SESSION[USERNAME]; ?>
<!--<br />
 --><?php //echo $_SESSION[STA]; ?>
</font>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--=============================================== -->
<!--<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script src="ckeditor/sample.js" type="text/javascript"></script>
<link href="ckeditor/sample.css" rel="stylesheet" type="text/css" />
 -->
<!--=============================================== -->
<!--<script type="text/javascript" src="nicEdit/nicEdit.js"></script>
 <script type="text/javascript">
	bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script> -->
<!--=============================================== -->
<SCRIPT language="JavaScript">
<!--
  function Conf(object) {
  if (confirm("คุณต้องการลบข้อมูล ใช่ หรือ ไม่ ?") == true) {
  return true;
  }
  return false;
  }
//-->
</SCRIPT>
<!--    onClick='return Conf(this)' -->

<script language="JavaScript" src="calendar/calendar.js"></script>
<link href="calendar/calendar-mos.css" rel="stylesheet" type="text/css">

<!--<script type="text/javascript" src="stmenu.js"></script><!--InCLUDE  TREE MANU  -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Supplements for seniors</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: x-small;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
body{
	background: #283943 url(images/body-bg.jpg)top center no-repeat;
}
p, h1, form, button{border:0; margin:0; padding:0;}
.spacer{clear:both; height:1px; margin: 0px auto;}
/* ----------- My Form ----------- */
.myform{
margin: 0px auto;
width:auto
padding:14px;

}


/* ----------- stylized ----------- */
#stylized{
border:solid 2px #b7ddf2;
background:#ebf4fb;
}
#stylized h1 {
font-size:14px;
font-weight:bold;
margin-bottom:8px;
}
#stylized p{
font-size:11px;
color:#666666;
margin-bottom:20px;
border-bottom:solid 1px #b7ddf2;
padding-bottom:10px;
}
#stylized label{
display:block;
font-weight:bold;
text-align:right;
width:140px;
float:left;
}
#stylized .small{
color:#666666;
display:block;
font-size:11px;
font-weight:normal;
text-align:right;
width:140px;
}
#stylized .smallStar{
color:#666666;
display:block;
font-size:11px;
font-weight:normal;
width:140px;
}
#stylized input{
float:left;
font-size:12px;
padding:4px 2px;
border:solid 1px #aacfe4;
width:200px;
margin:2px 0 20px 10px;
}
#stylized button{
clear:both;
margin-left:150px;
width:125px;
height:31px;
background:#666666 url(img/button.png) no-repeat;
text-align:center;
line-height:31px;
color:#FFFFFF;
font-size:11px;
font-weight:bold;
}

</style></head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">

  <tr>
    <td bgcolor="#FFFFFF"><fieldset>
    <div align="center"><img src="images/logotom.png" width="1000" height="200" />
      <?php
			  $topmenu = "topmenu.php";
			  include("$topmenu");?>
    </div>
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#83797A">
      <tr>
        <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td colspan="2" bgcolor="#FFFFFF">			  </td>
            </tr>
            <tr>
              <td width="19%" valign="top" bgcolor="#FFFFFF"><p>
                  <?php
				  $manu = "manu.php";
				  include("$manu"); ?>
              </p>                  </td>
              <td width="81%" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="10" cellpadding="0">
<?php if($_SESSION[USERNAME]){?>
                    <tr>
                      <td><div align="right"><img src="icon/icon-16-user.png" width="16" height="16" />เข้าสู่ระบบโดย
					  <?php
$qsta="SELECT * FROM `member` WHERE `username` = '$_SESSION[USERNAME]'";
$qrsta=mysql_query($qsta);
$rssta=mysql_fetch_array($qrsta);?>
<strong><?php echo $rssta[name];?></strong>
<strong><?php if($rssta[Status]=="ADMIN"){echo "[ผู้ดูแลระบบ]";}?></strong>
</div></td>
                    </tr>
<?php }?>

                    <tr>
                      <td><?php
			  if($_GET[main]){
								include($_GET[main].".php");
								}else{
								//include("show_product.php");
								include("main.php");
								}
			  ?></td>
                    </tr>
                </table></td>
            </tr>
            <tr>
              <td colspan="2" valign="top" bgcolor="#FFFFFF"><div id="stylized" class="myform">
                  <div align="center"><br />
                    </div>
              </div></td>
            </tr>
        </table></td>
      </tr>
    </table>
    </fieldset> </td>
  </tr>
</table>
<div align="center"><br />
</div>
</body>
</html>
