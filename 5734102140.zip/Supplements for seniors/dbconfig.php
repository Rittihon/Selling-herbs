<?php

$conn;

$server = "localhost"; //localhost
$user = "root"; // Username
$pass = ""; // Password
$dbname = "ecomjaroenjit"; //namedatabase

function conndb() {
  global $conn;
  global $server;
  global $user;
  global $pass;
  global $dbname;
  $conn = mysql_connect($server,$user,$pass);
mysql_select_db($dbname) ;
mysql_db_query($dbname,"SET NAMES tis620");
  if (!$conn)
    die("");

  mysql_select_db($dbname,$conn)
    or die("");
}

function closedb() {
  global $conn;
  mysql_close($conn);
}

?>
