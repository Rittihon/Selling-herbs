﻿<?php
include("function.php");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
mysql_connect("localhost","root","") or die("Cannot connect the Server");
mysql_select_db("stock") or die("Cannot select database");
mysql_query("set character set utf8");
?>
<?php
// ส่วนของการเพิ่ม ลบ แก้ไข ข้อมูลครับ
if($_POST['ADD']){
$q="INSERT INTO `stock`.`machinery` (
`id_mc` ,
`id_product` ,
`id_cat` ,
`name` ,
`price` ,
`id_unit`
)
VALUES (
NULL , '$_POST[id_product]', '$_POST[id_cat]', '$_POST[name]', '$_POST[price]', '$_POST[id_unit]'
);

";
mysql_query($q);
}
if($_GET['method']=="delete"){
	$q="DELETE FROM tbl_member WHERE member_id='".$_POST['id']."' ";
	mysql_query($q);
	exit;
}
if($_GET['method']=="getupdate"){
	$q="SELECT * FROM tbl_member WHERE member_id='".$_POST['id']."' ";
	$qr=mysql_query($q);
	$rs=mysql_fetch_array($qr);
	echo $rs['member_id']."|";
	echo $rs['member_name']."|";
	echo $rs['member_password']."|";
	echo $rs['member_fullname']."|";
	echo $rs['member_type'];
	exit;
}
?>
<?php
//////////////////////////////////////// เริ่มต้น ส่วนเนื้อหาที่จะนำไปใช้ในไฟล์ ที่เรียกใช้ด้วย ajax
?>
<form id="form_member" name="form_member" method="post" action="">
<table width="500" border="0" cellspacing="2" cellpadding="0">
  <tr>
    <td width="100" align="right">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="right">รหัสสินค้า</td>
    <td align="left"><input name="id_product" type="text" id="id_product"  /></td>
  </tr>
  <tr>
    <td align="right">ชื่อสินค้า</td>
    <td align="left"><textarea name="name" cols="50" rows="2" id="name"></textarea></td>
  </tr>
  <tr>
    <td align="right">หมวด</td>
    <td align="left">
	<select name="id_cat" id="id_cat">
	<?php
	$q="select * from category";
	$qr=mysql_query($q);
	while($rs=mysql_fetch_array($qr)){
	?>
      <option value="<?=$rs['id_cat']?>"><?=$rs['name_cat']?>&nbsp;<?=$rs['title']?></option>
	  <?php }?>
    </select>    </td>
  </tr>
  <tr>
    <td align="right">หน่วยนับ</td>
    <td align="left"><select name="id_unit" id="id_unit">
      <?php
	$q="select * from unit";
	$qr=mysql_query($q);
	while($rs=mysql_fetch_array($qr)){
	?>
      <option value="<?=$rs['id_unit']?>">
        <?=$rs['name_unit']?>
        </option>
      <?php }?>
    </select></td>
  </tr>
  <tr>
    <td align="right">ราคาต่อหน่วย</td>
    <td align="left"><input name="price" type="text" id="price"  />
      บาท</td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="left"><input type="submit" name="ADD" id="ADD" value="ADD" />
      &nbsp; <input type="button" name="cancel" id="cancel" value="Cancel" /></td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
</table>
</form>
<?php
$q="select * from machinery,category,unit WHERE category.id_cat = machinery.id_cat AND machinery.id_unit = unit.id_unit";
$q.=" ORDER BY machinery.id_mc DESC   ";
$qr=mysql_query($q);
$total=mysql_num_rows($qr);
$e_page=20; // กำหนด จำนวนรายการที่แสดงในแต่ละหน้า
if(!isset($_GET['s_page'])){
	$_GET['s_page']=0;
}else{
	$chk_page=$_GET['s_page'];
	$_GET['s_page']=$_GET['s_page']*$e_page;
}
$q.=" LIMIT ".$_GET['s_page'].",$e_page";
$qr=mysql_query($q);
if(mysql_num_rows($qr)>=1){
	$plus_p=($chk_page*$e_page)+mysql_num_rows($qr);
}else{
	$plus_p=($chk_page*$e_page);
}
$total_p=ceil($total/$e_page);
$before_p=($chk_page*$e_page)+1;
?>
<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: x-small;
}
-->
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td width="17" height="20" align="center" bgcolor="#CCCCCC">#</td>
  <td width="16" height="20" align="center" bgcolor="#CCCCCC">ID</td>
  <td width="94" height="20" align="center" bgcolor="#CCCCCC"><div align="left">รหัสสินค้า</div></td>
  <td width="440" align="center" bgcolor="#CCCCCC"><div align="left">ชื่อสินค้า</div></td>
  <td width="57" align="center" bgcolor="#CCCCCC"><div align="left">หน่วยนับ</div></td>
  <td colspan="2" align="center" bgcolor="#CCCCCC">ราคาขายต่อหน่วย</td>
  <td width="176" height="20" align="center" bgcolor="#CCCCCC"><div align="left">หมวด</div></td>
  <td height="20" colspan="2" align="center" bgcolor="#CCCCCC">จัดการ</td>
  </tr>
<?php
$i=1;
while($rs=mysql_fetch_array($qr)){
?>
<tr>
  <td height="20" align="center"><?=($chk_page*$e_page)+$i?></td>
  <td align="center"><?=$rs['id_mc']?></td>
  <td height="20" align="left">&nbsp; <?=$rs['id_product']?></td>
  <td height="20" align="left"><?=$rs['name']?></td>
  <td height="20" align="left"><?=$rs['name_unit']?> </td>
  <td width="41" height="20" align="left"><div align="right">
    <?=$rs['price']?>
  </div></td>
  <td width="76" align="left">&nbsp;บาท</td>
  <td height="20" align="center"><div align="left">
    <?=$rs['name_cat']?>
    &nbsp;
    <?=$rs['title']?>
  </div>    </td>
  <td width="44" height="20" align="center"><a href="#<?=$rs['member_id']?>" class="updateItem">แก้ไข</a></td>
  <td width="45" height="20" align="center"><a href="#<?=$rs['member_id']?>" class="delItem">ลบ</a></td>
</tr>
<?php $i++; } ?>
</table>

<?php if($total>0){ ?>
<div class="browse_page">
 <?php
 // เรียกใช้งานฟังก์ชั่น สำหรับแสดงการแบ่งหน้า
  page_navigator($before_p,$plus_p,$total,$total_p,$chk_page);
  ?>
</div>
<?php } ?>
