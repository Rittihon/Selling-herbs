﻿<?php
	class ClsJSFormValidation
	{
		function ShowJSFormValidationCode($FormName,$ControlNames,$ValidationFunctionName,$SameFields="",$ErrorMsgForSameFields="")
		{
			$JSValidation="<script language='javascript1.2'>
							function $ValidationFunctionName()
							{	\n";
			foreach($ControlNames as $SingleControlName=>$ConditionAndErrorMessage)
				foreach($ConditionAndErrorMessage as $Condition=>$ErrorMessage)
				{
					switch($Condition)
					{
						case "''": 		$JSValidation.="
											if(document.$FormName.$SingleControlName.value=='')
											{
												alert('$ErrorMessage');
												document.$FormName.$SingleControlName.focus();
												return false;
											 }	\n";
										break;
						case "EMail":	$JSValidation.="
											var checkEmail;
											checkEmail=document.$FormName.$SingleControlName.value;
											if(checkEmail=='')
											{
												alert('Please Enter Your Email Address.');
												document.$FormName.$SingleControlName.focus();
												return false;
											}
											if ((checkEmail.indexOf('@') <=0) || ((checkEmail.charAt(checkEmail.length-4) != '.') && (checkEmail.charAt(checkEmail.length-3) != '.')))
											{
												alert('Invalid Email Address.');
												document.$FormName.$SingleControlName.focus();
												return false;
											}	\n";
										break;
						default: 		$JSValidation.="
											if(document.$FormName.$SingleControlName.value==$Condition)
											{
												alert('$ErrorMessage');
												document.$FormName.$SingleControlName.focus();
												return false;
											 }	\n";
					}	//End of Switch
				}		//End of foreach($SingleControl as ControlName=>$ConditionForControl)
				if(is_array($SameFields))
				{
					$JSValidation.= "if(";
					foreach($SameFields as $SingleField)
						$JSValidation.= "document.$FormName.$SingleField.value!=";
					$JSValidation=substr("$JSValidation",0,strlen($JSValidation)-2);
					$JSValidation.=")
									{
										alert('$ErrorMsgForSameFields');
										document.$FormName.$SingleField.focus();
										return false;
									 }	\n";
				}
			$JSValidation.=" return true;
							 }		//End of JS Validation Function
							 </script>	\n";
			return $JSValidation;
		}
	}
?>
