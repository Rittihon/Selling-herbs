<?php include("connect/inc.php");?>
<?php include("function.php"); ?>
<?php

	$q="SELECT * FROM `orders`
WHERE `order_id` LIKE '$_GET[order_id]'";
	$qr=mysql_query($q);
	$rs=mysql_fetch_array($qr);

$customer_id = $_SESSION[USERNAME];


$order_date = date("Y-m-d"); // เก็บ วัน/เดือน/ปี ที่สั่งซื้อครับ
$order_time = date("H:i:s"); // เก็บเวลาที่สั่งซื้อ

// สร้างหมายเลขคำสั่งซื้อโดยเอาพวกเลข วัน ชั่วโมง วินาที ที่สั่งซื้อมาต่อเข้าด้วยกัน 
$tmp1 = date("dmy");
$tmp2 = date("H");
$tmp3 = date("is");
$order_id = $tmp1.$tmp2.$tmp3;

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">
<!--
.style1 {font-weight: bold}
.style2 {font-weight: bold}
-->
</style>
</head>

<body>
<div id="stylized" class="myform">

<center>
<strong>ใบแจ้งค่ารายการสินค้าที่สั่งซื้อ</strong>
</center>
<center>
<br>
<center>
  <table width="720" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><fieldset>
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="3" style="border-collapse: collapse; border: 1px dotted #008000">
        <tr>
          <td   colspan="5"><center>
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="50%" >&nbsp;<b>หมายเลขคำสั่งซื้อ : <? echo $_GET[order_id]; ?></b></td>
                  <td width="50%" >&nbsp;<b>วันที่สั่งซื้อ : <?=$rs['order_date']?><br>
                    &nbsp;เวลา :
                    <?=$rs['order_time']?>
                  </b></td>
                </tr>
                <!-- ในที่นี้ขอสมมุติ ชื่อ-นามสกุล ที่อยู่ของผู้สั่งซื้อ ให้เป็นค่าคงที่ไปก่อนเลยนะครับ แต่ในการใช้งานจริง คุณสามารถดึงเอาจากตารางลูกค้าในฐานข้อมูลออกมาแสดงได้โดยง่ายดายเลย -->
                <tr>
                  <td width="50%"  >&nbsp;ชื่อ - นามสกุล ของผู้สั่งซื้อ : </td>
                  <td width="50%"  >&nbsp;คุณ <?php
	 $q2="SELECT * FROM `member` WHERE `username` = '$rs[username]'";
	$qr2=mysql_query($q2);
	$rs2=mysql_fetch_array($qr2);
	echo $rs2[name];
				  ?></td>
                </tr>
                <tr>
                  <td width="50%"  >&nbsp;ที่อยู่ ของผู้สั่งซื้อ : </td>
                  <td width="50%"  ><?=$rs2[address]?></td>
                </tr>
              </table>
          </center></td>
        </tr>
        <tr>
          <td colspan="5"  ><hr color="#CCCCCC"></td>
          </tr>
        <tr>
          <td  >            <div align="left">ชื่อสินค้า
            </div></td>
          <td  >            <div align="left">ราคาต่อหน่วย
            </div></td>
          <td  ><center>
            จำนวน
          </center></td>
          <td colspan="2"  ><center>
            รวม
          </center></td>
        </tr><tr>
          <td colspan="5"  ><center>
            <hr color="#CCCCCC">
          </center>            </td>
          </tr>
        <?php
	 $q3="SELECT * FROM `orderdetails`,`product` WHERE `orderdetails`.`order_id` LIKE '$_GET[order_id]'
	 AND `orderdetails`.`pro_id` = `product`.`pro_id`
	 ";
	$qr3=mysql_query($q3);
	while($rs3=mysql_fetch_array($qr3)){
		?>
        <tr id="item<?php echo $itemNumber; ?>">
          <td width="625"  ><p class="style1">&nbsp;
                  <?=$rs3['pro_name']?></p></td>
          <td width="183"  ><p class="style2">&nbsp;<?php echo number_format($rs3['price'],2,'.',','); ?>&nbsp;</p></td>
          <td width="83"  ><p align="right"><?php echo number_format($rs3['qty'],0,'.',','); ?>&nbsp;</p></td>
          <td width="229"  ><p align="right" class="style2">&nbsp;
<?php echo number_format($rs3['qty'] * $rs3['price'],2,'.',',');
$total = $total + ($rs3['qty'] * $rs3['price']);
?>


&nbsp;</p></td>
          <td width="46"  ><strong>บาท</strong></td>
        </tr>
        <?php
        }
        ?>
		<?php
		$qSum = "SELECT SUM( price ) AS priceAll
FROM `orderdetails`
WHERE `order_id` LIKE '$_GET[order_id]'";
	$qrSum=mysql_query($qSum);
	$rsSum=mysql_fetch_array($qrSum);
	//$total = $rsSum[priceAll];
		?>
        <tr id="itemtotal">
          <td   colspan="5" align="left"><hr color="#CCCCCC"></td>
          </tr>
        <tr id="itemtotal">
          <td   colspan="3" align="left"><b>&nbsp;ราคารวม</b></td>
          <td><p align="right"><b><? echo number_format($total,2,'.',','); ?>&nbsp;&nbsp;</b> </td>
          <td><b>บาท</b></td>
        </tr>
        <tr id="itemtotal">
          <td   colspan="3" align="left"><b>&nbsp;ภาษีมูลค่าเพิ่ม (7%)</b></td>
          <td><div align="right"><b><? echo number_format(0.07*$total,2,'.',','); ?></b></div></td>
          <td><b>บาท</b></td>
        </tr>
        <tr id="itemtotal">
          <td   colspan="3" align="left"><b>ราคารวมทั้งสิ้น</b></td>
          <td><div align="right"><b><? echo number_format((0.07*$total)+$total,2,'.',','); ?>&nbsp;&nbsp;</b></div></td>
          <td><b>บาท</b></td>
        </tr>
        <tr id="itemtotal">
          <td   colspan="5" align="left"><br></td>
        </tr>
        <tr id="itemtotal">
          <td   colspan="5" align="left"><?php
		  $bank = "bank.php";
		  include($bank);
		  ?></td>
        </tr>
      </table>
      </fieldset>&nbsp;</td>
    </tr>
  </table>
</center>
<form>
<input type=button value="พิมพ์หน้านี้" onClick="window.print()">&nbsp;
</form>

</center>
</div>
</body>

</html>
