﻿<?php
$q="SELECT * FROM `product` WHERE `pro_id` = $_GET[id]";
	$qr=mysql_query($q);	
	$rs=mysql_fetch_array($qr);

?>
<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style>

<table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><fieldset><legend><strong>รายละเอียดสินค้า</strong></legend>
        <table width="1%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td><fieldset>
            <img src="Timageproduct/<?=$rs['pro_pix']?>" width="500" />
            </fieldset> </td>
          </tr>
        </table>
        <br />
        <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td><span class="style1">
            <?=$rs[pro_name];?>
            </span></td>
          </tr>
          <tr>
            <td><p>รายละเอียดสินค้า<br />
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <?=$rs[Title];?>
              <br />
              <?=$rs[Detail];?><br />
            </p>            </td>
          </tr>
          <tr>
            <td><div align="center">
              <table width="150" border="0" cellspacing="5" cellpadding="0">
                <tr>
                  <td width="84"><strong>ราคาปกติ</strong></td>
                  <td width="34"><div align="right"><?php echo number_format($rs['price_normal']);?></div></td>
                  <td width="32"><strong>บาท</strong></td>
                </tr>
                <tr>
                  <td><strong>ราคาพิเศษ</strong></td>
                  <td><div align="right">
                    <?php echo number_format($rs['price']);?>
                  </div></td>
                  <td><strong>บาท</strong></td>
                </tr>
              </table>
            </div></td>
          </tr>
          
          <tr>
            <td><div align="center"></div></td>
          </tr>
        </table>
        <p align="center">&nbsp;</p>
    </fieldset>
     </td>
  </tr>
</table>
