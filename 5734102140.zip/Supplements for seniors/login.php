﻿<table cellspacing="0" cellpadding="2" width="79%" 
                        align="center" border="0">
  <tbody>
    <tr>
      <td width="20%">

	  <form 
                              action="chklogin.php" method="post" name="checkForm" id="checkForm" onsubmit="return check()">
        <?php if($_GET[er]){?>
		<div align="center"><font color="#FF0000"><strong>ชื่อหรือรหัสผ่านไม่ถูกต้อง</strong></font></div>
		<?php }?>
		
        <table width="0%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td><fieldset><legend><strong><img src="icon/icon-48-user.png" width="48" height="48" />เข้าสู่ระบบ</strong></legend>
                <table cellspacing="0" cellpadding="0" align="center" 
                              border="0">
                  <tbody>
                    <tr>
                      <td width="194" 
                                height="17" align="left" valign="bottom" class="style9"><img src="icon/user_thief_baldie.png" width="16" height="16" />USERNAME :</td>
                    </tr>
                    <tr>
                      <td align="left" valign="bottom"><input name="username" id="username" size="30" />                      </td>
                    </tr>
                    <tr>
                      <td height="12" align="left" valign="bottom" class="style9"><img src="icon/poll.png" width="12" height="14" />PASSWORD :</td>
                    </tr>
                    <tr>
                      <td align="left" valign="bottom"><input 
                                name="password" type="password" 
                                class="textTitle3" id="password" size="30" />                      </td>
                    </tr>
                    <tr>
                      <td height="26" align="left" valign="bottom">
					  <div align="center">
<script language="JavaScript" type="text/javascript">
function check() {
if(document.checkForm.username.value=="") {
alert("กรุณากรอกUSERNAME") ;
document.checkForm.user_std.focus() ;
return false ;
}
else if(document.checkForm.password.value=="") {
alert("กรุณากรอกรหัสผ่าน") ;
document.checkForm.password.focus() ;
return false ;
}
else
return ture ;

}
</script>

						<input name="LOGIN" type="submit" class="headBig2" id="LOGIN" value="เข้าสู่ระบบ" />

                        <br />
                        <a href="?main=reg">สมัครสมาชิก</a></div></td>
                    </tr>
                  </tbody>
                </table>
                </fieldset>
             </td>
          </tr>
        </table>
        </form>
	  </td>
    </tr>
  </tbody>
</table>

