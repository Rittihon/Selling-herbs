﻿<?php
//////////////////////////////////
@session_start();
/*
session_unset("NUM");
session_unregister("NUM");

session_unset("CODE");
session_unregister("CODE");

session_unset("NAME");
session_unregister("NAME");

session_unset("OFFICE");
session_unregister("OFFICE");
*/

	session_destroy();

header("Location:index.php");
echo "<meta http-equiv=\"refresh\" content=\"0 url=index.php\">";


//////////////////////////////////
?>