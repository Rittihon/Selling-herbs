﻿<?php
require_once("ValidateForm.cls.php");
$Validity = new ClsJSFormValidation;
$FormName = "all";
$ControlNames=array("pro_name"	=>array("''" =>"กรุณากรอกชื่อสินค้า"),
					"price_normal"	=>array("''" =>"กรุณาใส่ข้อมูลราคาปรกติ "),
					"price"	=>array("''" =>"กรุณาใส่ข้อมูลราคาขาย")
					);
$ValidationFunctionName="CheckValidity";
$JsCodeForFormValidation=$Validity->ShowJSFormValidationCode($FormName,$ControlNames,$ValidationFunctionName,$SameFields,$ErrorMsgForSameFields);
echo $JsCodeForFormValidation;
//onClick="return CheckValidity();"

?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script src="ckeditor/sample.js" type="text/javascript"></script>
<link href="ckeditor/sample.css" rel="stylesheet" type="text/css" />

<?php
$nametb = "product";
$namektb = "pro_id";

	if(trim($_FILES["fileUpload"]["tmp_name"]) != "")
	{
		$images = $_FILES["fileUpload"]["tmp_name"];
		$todayrename = date("YmdHis");
		$new_images = "Thumbnails_".$_FILES["fileUpload"]["name"];
		move_uploaded_file($_FILES["fileUpload"]["tmp_name"],"Timageproduct/"."$todayrename".$_FILES["fileUpload"]["name"]);
		$pro_pix = $todayrename.$_FILES["fileUpload"]["name"];
		/*
		$width=100; //*** Fix Width & Heigh (Autu caculate) 
		$size=GetimageSize($images);
		$height=round($width*$size[1]/$size[0]);
		$images_orig = ImageCreateFromJPEG($images);
		$photoX = ImagesX($images_orig);
		$photoY = ImagesY($images_orig);
		$images_fin = ImageCreateTrueColor($width, $height);
		ImageCopyResampled($images_fin, $images_orig, 0, 0, 0, 0, $width+1, $height+1, $photoX, $photoY);
		ImageJPEG($images_fin,"Timageproduct/".$new_images);
		ImageDestroy($images_orig);
		ImageDestroy($images_fin);
		*/
		
		
		
	}

?>
<?php
// ส่วนของการเพิ่ม ลบ แก้ไข ข้อมูล
if($_POST['ADD']){
//=================================UPLOAD==============================

//====================================================================
$q="INSERT INTO `$db`.`$nametb` (
`pro_id` ,
`group_id` ,
`pro_name` ,
`pro_pix` ,
`Title` ,
`Detail` ,
`price_normal` ,
`price` 
)
VALUES (
NULL , '$_POST[group_id]', '$_POST[pro_name]  ', '$pro_pix', '$Title', '$_POST[Detail]', '$_POST[price_normal] ', '$_POST[price]'
);
";
mysql_query($q);	
}
if($_GET['del']){
//$q="DELETE FROM ".$nametb." WHERE "."$namektb"."="."'".$_GET['del']."' ";
 $q = "UPDATE `$db`.`product` SET `status` = 'N' WHERE `product`.`pro_id` =$_GET[del]
";
mysql_query($q);
delcom();	
//exit;
}
if($_GET['up']){
	$q="SELECT * FROM ".$nametb." WHERE "."$namektb"."="."'".$_GET['up']."' ";
	$qr=mysql_query($q);	
	$rs=mysql_fetch_array($qr);
}
?>
<?php
if($_POST['UPDATE']){
$q="UPDATE `$db`.`$nametb` SET 
`group_id` = '$_POST[group_id]',
`pro_name` = '$_POST[pro_name]',
`Detail` = '$_POST[Detail]',
`price_normal` = '$_POST[price_normal]',
`price` = '$_POST[price]',
`Title` = '$_POST[Title]'";
if(trim($_FILES["fileUpload"]["tmp_name"]) != ""){
$q.=", `pro_pix` = '$pro_pix'";
}
$q.=" WHERE `$nametb`.`$namektb` = $_POST[pro_id];";
//echo $q;
mysql_query($q);
}
?>

<style type="text/css">
<!--
.style3 {font-weight: bold}
.style4 {font-weight: bold}
-->
</style>

<div id="stylized" class="myform">

<form action="" method="post" enctype="multipart/form-data" name="frmMain">  <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td>        <legend></legend>        
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="2">
          <tr>
            <td colspan="2" align="right"><div align="left">
              <h1><img src="icon/cart.gif" width="16" height="17" />ข้อมูลสินค้า</h1>
              <br />
             <p> เพิ่มและแก้ใขสินค้า</p>
            </div></td>
            </tr>
          <tr>
            <td align="right">&nbsp;</td>
              <td width="762" align="left"><em>
                <?php if($_GET['up']){?>
                <input name="pro_id" type="hidden" id="pro_id" value="<?=$rs['pro_id']?>" />
                <?php }?>
              </em></td>
            </tr>
          <tr>
            <td width="158" align="right"><strong>ชื่อสินค้าใส่ชื่อของสินค้า</strong></td>
              <td align="left"><em>
                <input name="pro_name" type="text" id="pro_name" value="<?=$rs['pro_name']?>" size="50" />
              </em></td>
            </tr>
          
          <tr>
            <td align="right"><strong>รายละเอียดสินค้าเบื้องต้น</strong><br />
              <span class="small">รายละเอียดสินค้าเบื้ิองต้น สั้นๆ </span></td>
            <td align="left"><input name="Title" type="text" id="Title" value="<?=$rs['Title']?>" /></td>
          </tr>
          <tr>
            <td align="right"><strong>หมวด</strong><br />
              <span class="small">กรุณาเลือกหมวดหมู่ของสินค้า</span></td>
              <td align="left"><em>
                 &nbsp;
                 <select name="group_id" class="style3" id="group_id">
                  <?php 
	$q2="SELECT * FROM `group`  ";
	$qr2=mysql_query($q2);
	while($rs2=mysql_fetch_array($qr2)){	
	?>
                  <option value="<?=$rs2['group_id']?>" <?php if($rs2['group_id']==$rs['group_id']){ print 'selected="selected"';}?> >
                  <?=$rs2['group_name']?>
                  </option>
                  <?php }?>
                </select>
              </em></td>
            </tr>
          <tr>
            <td align="right"><strong>ราคาปรกติ</strong><br />
              <span class="small">ราคาขายตามท้องตลาดปรกติ</span></td>
              <td align="left"><em>
                <input name="price_normal" type="text" id="price_normal" value="<?=$rs['price_normal']?>" />
              </em>บาท</td>
            </tr>
          <tr>
            <td align="right"><strong>ราคาขาย</strong><br />
              <span class="small">ราคาขายจริง</span></td>
              <td align="left"><em>
                <input name="price" type="text" id="price" value="<?=$rs['price']?>" />
              </em>บาท</td>
            </tr>
          <tr>
            <td align="right"><strong>ภาพ</strong><span class="small">ภาพสินค้า</span></td>
              <td align="left"><em>
                <input name="fileUpload" type="file">
              </em></td>
            </tr>
          <tr>
            <td colspan="2" align="right"><div align="left"><strong>รายละเอียดสินค้า</strong><br />
              <span class="small">รายละเอียดของสินค้า</span></div></td>
            </tr>
          <tr>
            <td colspan="2" align="right"><div align="center">
                  <em> &nbsp;</em>
                  <textarea class="ckeditor" cols="80" id="Detail" name="Detail" rows="10"><?=$rs['Detail']?>
                  </textarea>
  &nbsp;</div></td>
            </tr>
          <tr>
            <td align="right">&nbsp;</td>
              <td align="left"><em>
                <?php if($_GET['up']){?>
                <input type="submit" name="UPDATE" id="UPDATE" value="UPDATE" />
                <?php }else{?>
                <input type="submit" name="ADD" id="ADD" value="ADD" onClick="return CheckValidity();" />
                <?php }?>
                <input type="button" name="cancel" id="cancel" value="Cancel" />
              </em></td>
            </tr>
        </table></td></tr>
  </table>
</form>

<?php
$q="SELECT * 
FROM `$nametb` 
WHERE `status` = 'Y'
ORDER BY `$nametb`.`$namektb` DESC   ";
$qr=mysql_query($q);
$total=mysql_num_rows($qr);
$e_page=20; // กำหนด จำนวนรายการที่แสดงในแต่ละหน้า   
if(!isset($_GET['s_page'])){   
	$_GET['s_page']=0;   
}else{   
	$chk_page=$_GET['s_page'];     
	$_GET['s_page']=$_GET['s_page']*$e_page;   
}   
$q.=" LIMIT ".$_GET['s_page'].",$e_page";
$qr=mysql_query($q);
if(mysql_num_rows($qr)>=1){   
	$plus_p=($chk_page*$e_page)+mysql_num_rows($qr);   
}else{   
	$plus_p=($chk_page*$e_page);       
}   
$total_p=ceil($total/$e_page);   
$before_p=($chk_page*$e_page)+1; 
?>
<style type="text/css">
<!--
body,td,th {
	font-family: Tahoma;
	font-size: x-small;
}
-->
</style>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td>      <table width="100%" border="0" align="center" cellpadding="3" cellspacing="0">
        <tr>
          <td width="124" height="20" align="center" bgcolor="<?=$CH?>"><strong>รูปภาพ</strong></td>
          <td width="570" align="center" bgcolor="<?=$CH?>"><div align="left"><strong>ชื่อสินค้า</strong></div>          <div align="left"></div></td>
            <td width="122" height="20" align="center" bgcolor="<?=$CH?>"><strong>ราคาขาย
            </strong>          <div align="left"></div></td>
            <td height="20" colspan="2" align="center" bgcolor="<?=$CH?>"><a href="?main=<?=$_GET[main]?>"><strong><img src="icon/add.png" alt="เพิ่ม" width="16" height="16" border="0" /></strong></a></td>
          </tr>
        <?php
$i=1;
while($rs=mysql_fetch_array($qr)){
?>
        <?php 
$bg = ($bg=="$CLTB1")?"$CLTB2":"$CLTB1";
?>
        <tr bgcolor="<?php echo $bg?>" onmouseover="bgColor='<?=$CLOVER?>'" onmouseout="bgColor='<?=$bg?>'">
          <td height="20" align="left">&nbsp;<fieldset>
            <a href="#">
              
              <img src="Timageproduct/<?php if($rs['pro_pix']){ echo $rs['pro_pix'];}else{echo "nopix.gif";}?>" width="140" border="0" />              </a>
            </fieldset></td>
            <td height="20" align="left"><span class="style4">
              <?=$rs['pro_name']?>
            </span>
              <legend></legend>              <p>
                <?=$rs['Title']?>
            </p></td>
            <td height="20" align="left">    
              <div align="center"><?=$rs['price']?>
              บาท          </div>
            <div align="left"></div></td>
            <td width="16" height="20" align="center"><a href="?main=<?=$_GET[main]?>&up=<?=$rs[$namektb]?>" class="updateItem"><img src="icon/edit.png" alt="แก้ไข" width="16" height="16" border="0" /></a></td>
            <td width="16" align="center"><a href="?main=<?=$_GET[main]?>&del=<?=$rs[$namektb]?>" class="updateItem"><img src="icon/cross.gif" alt="ลบ" width="16" height="16" border="0" onClick='return Conf(this)' /></a></td>
          </tr>
        <?php $i++; } ?>
      </table>
   </td></tr>
</table>
<?php if($total>0){ ?>
<div class="browse_page">
  <div align="center">
    <?php   
 // เรียกใช้งานฟังก์ชั่น สำหรับแสดงการแบ่งหน้า   
  page_navigator($before_p,$plus_p,$total,$total_p,$chk_page);     
  ?>
    <br />
    ทั้งหมด  <?php echo $total ; ?>รายการ
    
  </div>
</div>
<div align="center">
  <?php } ?>
</div>
</div>
