<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top"><?php 
	$show_product = "show_product.php";
	include($show_product);?></td>
  </tr>
</table>