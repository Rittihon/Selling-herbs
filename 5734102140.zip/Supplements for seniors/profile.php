﻿<?php
$nametb = "member";
$namektb = "username";
?>

<?php
if($_POST['UPDATE']){
 $q="UPDATE `$db`.`$nametb` 
SET `password` = '$_POST[password]', 
`name` = '$_POST[name]',
`address` = '$_POST[address]',
`email` = '$_POST[email]',
`identily` = '$_POST[identily]',
`tel` = '$_POST[tel]' 
WHERE `member`.`username` = '$_POST[username]'
";
//echo $q;
mysql_query($q);
	print("<script language=javascript>
	window.alert('แก้ไขข้อมูลเรียบร้อยแล้ว');
	</script>");

//Topage("index.php?main=profile");
}

// ส่วนของการเพิ่ม ลบ แก้ไข ข้อมูล
if($_POST['ADD']){
	$q="INSERT INTO `$db`.`member` (
`username` ,
`password` ,
`name` ,
`address` ,
`email` ,
`identily` ,
`tel` 
)
VALUES (
'$_POST[username] ', '$_POST[password]', '$_POST[name]', '$_POST[address]', '$_POST[email]', '$_POST[identily]  ', '$_POST[tel]'
);
";
mysql_query($q);	
}
if($_GET['del']){
$q="DELETE FROM `$db`.`$nametb` WHERE `$nametb`.`$namektb` = '$_GET[del]';
";
mysql_query($q);
delcom();	
//exit;
}
	$q="SELECT * FROM `member` WHERE `username` = '$_SESSION[USERNAME]'";
	$qr=mysql_query($q);	
	$rs=mysql_fetch_array($qr);
?>
<?php

?><div id="stylized" class="myform">

<form action="" method="post" enctype="multipart/form-data" name="frmMain">  <table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td>        <legend></legend>        
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="2">
          <tr>
            <td colspan="2" align="right"><div align="left">
              <h1>ข้อมูลส่วนตัว</h1>
              <br />
              ข้อมูลส่วนตัวของคุณ</div></td>
            </tr>
          <tr>
            <td width="158" align="right" valign="top">&nbsp;</td>
              <td width="762" align="left" valign="top">&nbsp;</td>
            </tr>
          <tr>
            <td valign="top"><div align="right"><strong>ชื่อผู้ใช้</strong></div>
                <div align="right"><span class="small">Username</span> </div></td>
            <td valign="top"><em>
              <input name="username"  type="text" id="username" value="<?=$rs[$namektb]?>"  readonly="readonly"/>
            </em></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>รหัสผ่าน<br />
                      <span class="small">Password</span></strong></div></td>
            <td valign="top"><input name="password" type="password" id="password" value="<?=$rs[password]?>" /></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>ชื่อ-สกุล<br />
                      <span class="small">Name-Lastname</span></strong></div></td>
            <td valign="top"><input name="name" type="text" id="name" value="<?=$rs[name]?>" /></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>รหัสบัตรประชาชน<br />
                      <span class="small">identily</span></strong></div></td>
            <td valign="top"><input name="identily" type="text" id="identily"  value="<?=$rs[identily]?>"/></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>ที่อยู่</strong></div>
                <div align="right"><strong><span class="small">ที่อยู่ในการจัดส่งสินค้า</span><br />
              </strong></div></td>
            <td valign="top">&nbsp;&nbsp;
              <textarea name="address" cols="60" rows="5" id="address" ><?=$rs[address]?></textarea></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>เบอร์โทร<br />
                      <span class="small">ที่สามารถติดต่อได้</span></strong></div></td>
            <td valign="top"><input name="tel" type="text" id="tel" value="<?=$rs[tel]?>" /></td>
          </tr>
          <tr>
            <td valign="top"><div align="right"><strong>Email<br />
                      <span class="small">จดหมายอิเล็กทรอนิกส์</span></strong></div></td>
            <td valign="top"><input name="email" type="text" id="email" value="<?=$rs[email]?>" /></td>
          </tr>
          
          <tr>
            <td align="right">&nbsp;</td>
              <td align="left"><em>
                <input type="submit" name="UPDATE" id="UPDATE" value="UPDATE" />
              </em></td>
            </tr>
        </table></td></tr>
  </table>
</form>

<div align="center"></div>
</div>
